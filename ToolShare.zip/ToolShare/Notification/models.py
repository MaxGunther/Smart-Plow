from django.db import models

class Notification(models.Model):
    user = models.IntegerField(max_length=50)       #User to display notification to
    tool = models.IntegerField(max_length=50)       #Tool requested to borrow
    borrowOn = models.IntegerField(max_length=20)   #Time requested to be borrowed
    due = models.IntegerField(max_length=20)        #Time tool should returned
    borrowerID = models.IntegerField(max_length=50) #User sending the request
    isRead = models.IntegerField(max_length=1)      # 0 if unread, 1 if read
    isDenied = models.IntegerField(max_length=1)    # 0 if not denied, 1 if denied, 2 if approved

    def __str__(self):
        return self.id

    def markRead(self):
        self.isRead = 1

    def confirm(self):
        self.isRead = 1
        #Defered import
        from Tool.models import Tool
        t = Tool.objects.get(id=self.tool)
        t.currOwner = self.borrower
        
    def changeNotification(self,request):
        operation = request.POST.get("operation","noop")
        #Delete
        if operation == "delete":
            self.delete()
        elif operation == "approve":
            from Tool.models import Tool
            toolObject = Tool.objects.get(id=self.tool)
            if toolObject.currowner == 0:
                toolObject.checkout(self.borrowerID)
                n = Notification(user=self.borrowerID, tool=self.tool, isRead=0, borrowerID=0, \
                                 borrowOn = 0, due = 0, isDenied = 2)
                n.save()
                self.delete()
            else:
                pass
        elif operation == "deny":
            n = Notification(user=self.borrowerID, tool=self.tool, isRead=0, borrowerID=0, \
                         borrowOn = 0, due = 0, isDenied = 1)
            n.save()
            self.delete()
        else:
            pass
            