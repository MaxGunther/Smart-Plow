function navDown(){
/*
	var backlighting = document.querySelector('.backlighting');
	backlighting.style.zIndex = "1";
*/}

function navUp(){
	var backlighting = document.querySelector('.backlighting');
	backlighting.style.zIndex="-1";
}

function refreshClock(){
	var clock = document.getElementById('clock');
	var d = new Date();
	clock.innerHTML = d.toLocaleTimeString();
	
	setTimeout(refreshClock,1000);
}

function refreshNotifications(){
    var notifications = document.getElementById("notifications");
    $.get("notifications",
        function(data){
            notifications.innerHTML = data;
            var start = document.querySelectorAll(".start, .end");
            for(var i = 0; i < start.length; i++){
                var j = parseInt(start[i].innerHTML);
                if(j!=NaN){
                    var d = new Date(j);
                    var str = d.toDateString();
                    if(str!="Invalid Date"){
                        start[i].innerHTML = str;
                    }
                }
            }
        }
    );
    
    setTimeout(refreshNotifications,5000);
}

function displayDeferred(){
    var def = $(".deferred");
    def.css("display","none");
    def.each(function(index){
        $(this).delay(fadeDifference*index).fadeIn(fadeSpeed);
    });
}

var notificationsExpanded = false;
var notificationsWidth = 0;
var htmlBackBuffer = "";
var fadeSpeed = 150, fadeDifference = 10;
var transition = function(query, callback){
    return $.when(query.fadeOut(fadeSpeed)).done(callback);
};
function toggleNotifications(){
    var ne = notificationsExpanded;
    notificationsExpanded = !ne;
    if(!ne){
        htmlBackBuffer = $(".content").html();
        transition($(".content :visible"),function(){
            $(".content").html($(".notifications").html());
            $(".content .expanded").css("display","none");
            $(".content .expanded").show(fadeSpeed);
        });
    } else {
        $.when($(".content .expanded").hide(fadeSpeed)).done(function(){
            $(".content").html(htmlBackBuffer);
            var visible = $(".content :visible");
            visible.css("display","none");
            visible.show(fadeSpeed);
        });
    }
    
}

/** Alters the notification of the given id; valid operations 
include approving, denying, reading, and deleting.*/
function changeNotification(id, operation){
    $.post("postOp", {id:id, operation:operation}, function(data){refreshNotifications();});
}

function loadHeader(username,authorized){
    
	var hrefs = new Array("userHome","search","tools","sheds");
	var buttons = new Array("Home","Search","Tools","Sheds");
	var header = document.getElementById('header');
    if(header==null){
        return;
    }
	
    var auth = authorized=="True";
    
	if(auth){
		hrefs.push("myAccount");
		hrefs.push("logOut");
		buttons.push("My Account");
		buttons.push("Log Out");
	} else {
		hrefs.push("login");
		hrefs.push("register");
		buttons.push("Log In");
		buttons.push("Register");
	}
    
    var current = window.location.href;
    current = current.substring(current.lastIndexOf("/")+1, current.length);
    //var matched = false;
	var profileBase = "../PicStatic/Profiles/", 
        profileDefault = profileBase + "Default/default.png",
        profileImage = profileBase+username+'.png';
    
	var inner='<div class="nav" onmouseover="navDown()" onmouseout="navUp()">'
    +'<table class="fillW"><tr><td class="stretch"></td><td>'
    +'<div id="notifications" class="notifications"></div>'
    +'</tr></table>';
    inner += '<br><table><tr><td>'
    var home = (current=='home' || current=='');
	for(var i = 0; i < hrefs.length; i++){
        var highlight = ((current==hrefs[i])||(home&&hrefs[i]=="userHome"));
		inner+='<a'
			+' class="button bordered deferred'+(highlight?' hilite':'')+'"'
			+' href="http://127.0.0.1:8000/'+hrefs[i]+'">'
			+buttons[i]+'</a>';
	}
    inner+='</td></tr><tr><td>';
    if(!auth){
        inner += '<div id="zipGuest center" class="deferred">'
            +'Zipcode:<br>'
            +'<input type="hidden" name="operation" value="changeZip">'
            +'<input maxLength=5 class="fillW" type="text" name="zipcode" value="14623">'
            +'<input type="hidden" name="origin" value="home">'
            +'<a class="button" href="javascript:{}" onclick="changeZip()">Update</a>'
        +'</div>';
    }
    inner+="</td></tr></table>";
    
	inner+='</div><div class="backlighting"><div id="clock"></div></div>';
	header.innerHTML = inner;
    
    refreshNotifications();
    
    displayDeferred();
	setTimeout(refreshClock,0);
    
    
    if(!auth){
        $("#zipGuest input").bind("keydown",function(event){
            event.preventDefault();
            changeZip();
        });
    }
}