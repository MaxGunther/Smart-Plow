function fleshOut(dest, src){
	$('#'+dest).load(src);
}

function startRefreshTools(){
	setTimeout(refreshAndWaitTools,0);
}

function startRefreshSearch(){
    setTimeout(refreshAndWaitSearch,0);
}

function refreshAndWaitTools(){
    updateToolQuery();
    setTimeout(refreshAndWaitTools,5000);
}

function refreshAndWaitSearch(){
    updateQuery();
    setTimeout(refreshAndWaitSearch,5000);
}

function startRefreshSheds(){
    setTimeout(refreshAndWaitSheds,0);
}

function refreshAndWaitSheds(){
    updateShedQuery();
    setTimeout(refreshAndWaitSheds,5000);
}

function updateToolQuery(){
    var tQuery = document.getElementById("toolQuery");
    
    if(tQuery){
        var search = $("#toolSearch input");
        $.post('importTools',
        {
            searchName:search[0].value,
            searchDesc:search[1].value,
            searchUser:search[2].value,
            searchAvail:search[3].value
        },
        function(data){
            var display = tQuery.style.display;
            tQuery.innerHTML = data;
            tQuery.style.display = display;
        });
    }
    
}

function updateQuery(){
    var query = document.getElementById("query");
    if(query){
        //var search = $("#search input");
        var search = document.querySelectorAll("#search input");
        $.post('importSearch',
        {
            query:search[0].value,
            includeTools:search[1].checked?"True":"False",
            includeSheds:search[2].checked?"True":"False",
            //includeUsers:search[3].checked?"True":"False"
        },
        function(data){
            var display = query.style.display;
            query.innerHTML = data;
            query.style.display = display;
        });
    }
}

function updateShedQuery(){
    var sQuery = document.getElementById("shedQuery");
    if(sQuery){
        $.get("importSheds", function(data){
            var display = sQuery.style.display;
            sQuery.innerHTML = data;
            sQuery.style.display = display;
        });
    }
}