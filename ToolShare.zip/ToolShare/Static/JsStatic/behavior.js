
/** Automatically hides all of the popups on the page. */
$(document).ready(function(){
    $(".popup").css("display","none");
});

var mode = -1, fadeSpeed = 150;
/** Hides the last popup and displays the popup with the given index. */
function changeMode(newMode, speed){
    if(arguments.length==1){
        speed="fast";
    }
    var popups = $(".popup");
    var popup1 = popups[mode];
    var popup2 = popups[newMode];
    
    var jqPopup1 = $(".popup").eq(mode);
    var jqPopup2 = $(".popup").eq(newMode);
    
    var pos = mode>=0;
    mode = newMode;
    
    if(pos){
        jqPopup1.hide(fadeSpeed);
    }
    jqPopup2.show(fadeSpeed);
    
}

/** Checks to see if the given string is empty. */
function empty(str){
	return (str.length == 0);
}

/** Checks the fields for validity, then either attempts 
to submit the request or display the appropriate errors. */
function submitLogin(){
	var n = document.getElementById('name').value;
	var p = document.getElementById('pass').value;
	var nEmpty = empty(n);
	var pEmpty = empty(p);
	if(nEmpty || pEmpty){
		$("#error").show();
        var lis = $("#error li");
        lis[0].style.display = nEmpty?"list-item":"none";
        lis[1].style.display = pEmpty?"list-item":"none";
	} else {
        var login = document.getElementById("login");
        login.submit();
	}
}

/** Checks the zipcode for validity: 5 numerical characters.
Testing for real-world validity is not implemented. */
function validZip(zip){
	return (zip.length==5)&&(/^[0-9]{5,}$/.test(zip));
}

/** Checks the fields for validity: must not be empty, and must
match the expected patterns (email follows x@y.z, passwords must 
be identical) */
function submitUserReg(){
	
	var name = document.getElementById("name").value;
	var zip = document.getElementById("zip").value;
	var pass = document.getElementById("pass").value;
    var pass2 = document.getElementById("pass2").value;
	
	var nameEmpty = empty(name);
	var zipEmpty = empty(zip);
	var zipInvalid = !validZip(zip);
	var passEmpty = empty(pass);
    var passEmpty2 = empty(pass2);
    var errors = new Array(nameEmpty,zipEmpty,zipInvalid,passEmpty,passEmpty2);
    
	if(nameEmpty || zipEmpty || zipInvalid || passEmpty || passEmpty2){
		
        $("#error").show();
        var children = $("#error li");
        
        for(var i = 0; i < 5; i++){
            if(errors[i]){
                children[i].style.display='block';
            } else {
                children[i].style.display='list-item';
            }
        }
		
	} else {
		document.getElementById('register').submit();
	}
}

/** A series of callbacks for use in form submissions; 
each handles the server response differently. */
var defaultCallback = function(form){
    form.submit();
}, toolViewCallback = function(form){
    $.post("postOp", 
        form.serialize(),
        function(data){
            updateToolQuery();
        }
    );
}, shedViewCallback = function(form){
    $.post("postOp", 
        form.serialize(),
        function(data){
            updateShedQuery();
            //changeMode(0);
        }
    );
}, zipCallback = function(form){
    $.post("postOp", 
        form.serialize(),
        function(data){
            location.refresh();
        }
    );
}, loginCallback = function(data){
    //form.submit();
    /*$.post("login",
        {},
        function(data){
            alert("Log in attempted.");
        });*/
}, homeCallback = function(data){
    window.location.assign("http://127.0.0.1:8000/userHome");
}, searchCallback = function(form){
    $.post("#postOp",
    {toolName:"",toolDesc:"",origin:""},
    //form.serialize(),
    function(data){
        updateQuery();
        changeMode(1);
    });
};

/** Unified POST request handler. Sets all of the appropriate fields in the form,
submits the form, and calls the given callback, which might refresh associated content. */
function submitPostOpCallback(callback, argIndices, args){
    var form = $("#postOp");
    
	var inputs = form.children();
    
    for(var i = 0; i < args.length; i++){
        inputs[argIndices[i]].value = args[i];
    }
    
    callback(form);
}

/** Submits the form with the default callback instead of a specialized handler. */
function submitPostOp(argIndices, args){
    return submitPostOpCallback(defaultCallback, argIndices, args);
}

/** Deletes the tool with the given ID. */
function deleteTool(id){
    var tool = $("#tool"+id);
    if(tool){
        $.when(tool.fadeOut());
    }
    setTimeout(function(){
            submitPostOpCallback(toolViewCallback, new Array(0,1), new Array("deleteTool", id));
        }, fadeSpeed);
}

/** Submits a new tool to the database. */
function submitNewTool(){
    var srcInputs = jQuery("#newTool input");
    submitPostOpCallback(toolViewCallback, new Array(0,2,4,10), 
        new Array("addTool",srcInputs[0].value,srcInputs[1].value,location.href));
}

/** Returns a borrowed tool, likely ending the current borrow request. */
function returnTool(toolID){
    submitPostOpCallback(toolViewCallback, new Array(0,1), new Array("returnTool",toolID));
}

/** Selects the given tool for viewing. */
function selectTool(toolID){
    var inputs = $("#toolRequest input");
    inputs[0].value = toolID;
    changeMode(2);
}

/** Clears the queries in the Tools page. */
function clearToolSearch(){
    $("#toolSearch input").each(function(index,element){
        element.value=element.defaultValue;
    });
    toolViewCallback($("#postOp"));
}

/** Clears the query in the dedicated search page. */
function clearSearch(){
    $("#search input").each(function(index,element){
        element.value = element.defaultValue;
    });
    updateQuery();
    //searchCallback($("#postOp"));
}
/** Gives the shed to the given user. */
function giveShed(obj){
    var selObj = obj.find(":selected");
    var id = selObj.attr('id');
    var username = selObj.text();
    //alert("Given: id=" + id + ", username=" + username+".");
    $.post("postOp", {shedID:id, userName:username}, function(data){location.reload();});
}

function requestTool(){
    var inputs = $("#toolRequest input");
    submitPostOpCallback(toolViewCallback, new Array(0,1,5,6), new Array("requestTool",inputs[0].value, inputs[1].value, inputs[2].value));
}

/** Borrows the tool; assumes the tool has already been requested and approved. */
function borrowTool(){
    var inputs = $("#toolRequest input");
    submitPostOpCallback(toolViewCallback, new Array(0,1), new Array("borrowTool",inputs[0].value));
}

/** Submits a new shed to the database. */
function submitNewShed(){
    var inputs = $("#newShed input");
    submitPostOpCallback(shedViewCallback, new Array(0,1,3), 
        new Array("addShed", inputs[0].value, 
            $("#newShed").find(":selected").text()));
    changeMode(0);
}

/** Deletes the tool of the given ID from the database. */
function deleteShed(id){
    submitPostOpCallback(shedViewCallback, new Array(0,2), new Array("deleteShed",id));
}

/** Changes the zipcode of the anonymous user. */
function changeZip(){
    var inputs = $("#zipGuest input");
    $.post("postOp", 
        {operation:"changeZip", zipcode:parseInt(inputs[1]), origin:location.href}, 
        function(data){});
    
}

/** Submits the profile picture to the database. */
function submitPic(){
    var dict = $("#picForm").serialize();
    dict["operation"] = "uploadPic";
    $.post("postOp",dict,function(data){location.reload();});
/*    $.when(document.getElementById("picForm").submit()).done(function(){
        location.reload();
    });*/
}