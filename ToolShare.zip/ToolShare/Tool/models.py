from django.db import models

class Tool(models.Model):
    name = models.CharField(max_length=50)                      #Name of tool
    description = models.TextField()                            #Description of tool
    borrowOn = models.IntegerField(max_length=20)               #Time requested to be borrowed
    due = models.IntegerField(max_length=20)                    #Time tool should returned
    location = models.IntegerField(max_length=5)                #Zip Code
    owner = models.IntegerField(max_length=50)                  #ID of owner
    currOwner = models.IntegerField(max_length=50)              #ID of borrower, 0 if not borrowed
    shed = models.IntegerField(max_length=50)                   #ID of shed

    def __str__(self):
        return self.id

    def getID(self):
        return self.id

    def checkOut(self, userID):
        self.currOwner = userID
        self.save()

    def request(self, borrower, borrowTime, dueTime):
        #Defered imports
        from Notification.models import Notification
        n = Notification(user=self.owner, tool=self.id, isRead=0, borrowerID=borrower, \
                         borrowOn = 0, due = 0, isDenied = 0)
        n.save()

    def checkIn(self):
        self.currOwner = 0
        self.save()

    def editDescription(self, newDescription):
        self.description = newDescription
        self.save()