from django.test import TestCase
from Tool.models import Tool
from ToolUser.models import ToolUser

class Max_test_case(TestCase):
    def test(self):
        user = ToolUser(name = "Bob", location = 12345, coordinator = -1)
        tool1 = Tool(name = "Hammer", description = "One big hammer", location = 12345, owner = user.getID(), currOwner = 0, shed = user.getID())
        tool2 = Tool(name = "Hammer", description = "One smaller hammer", location = 12345, owner = user.getID(), currOwner = 0, shed = user.getID())
        self.assertEqual(user, ToolUser(name = "Bob", location = 12345, coordinator = -1))
        self.assertEqual(tool1, Tool(name = "Hammer", description = "One big hammer", location = 12345, owner = user.getID(), currOwner = 0, shed = user.getID()))
        self.assertEqual(tool2, Tool(name = "Hammer", description = "One smaller hammer", location = 12345, owner = user.getID(), currOwner = 0, shed = user.getID()))
        self.assertEqual(user.location, 12345)
        self.assertEqual(user.name, 'Bob')
        self.assertEqual(user.coordinator, -1)
        self.assertEqual(tool1.name, "Hammer")
        self.assertEqual(tool2.name, "Hammer")
        self.assertEqual(tool1.description, "One big hammer")
        self.assertEqual(tool1.description, "One smaller hammer")