from django.test import TestCase
from Tool.models import Tool
from ToolUser.models import ToolUser
from ToolContainer.models import Shed

class Max_test_case2(TestCase):
    def test(self):
    	user1 = ToolUser(name = "Alex", location = 11111, coordinator = -1)
    	user2 = ToolUser(name = "Charlie", location = 11111, coordinator = -1)
    	Shed = Shed(location = 11111, coordinator = 0, title = "shed1")
    	self.assertEquals(Shed.title,  "shed1")
    	self.assertEquals(Shed.location, 11111)