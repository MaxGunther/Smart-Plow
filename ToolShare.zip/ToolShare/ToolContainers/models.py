from django.db import models

from Tool.models import Tool

class ShareZone(models.Model):
    location = models.IntegerField(max_length=5)    #Zip Code

    def __str__(self):
        return self.location
    
    def createShed(self, coordinatorID, name):
        s = Shed(location=self.location, coordinator=coordinatorID, title=name)
        s.save()

    def allTools(self):
        mainLst = []
        for tool in Tool.objects.filter(location__exact=self.location):
            toolLst = [tool.id, tool.name, tool.description, tool.currOwner]
            mainLst.append(toolLst)
        mainLst.sort(key=lambda tool: tool[0])
        return mainLst
    
    def deleteShed(self, shedID):
        s = Shed.objects.get(id=shedID)
        s.delete()

    def searchTools(self, name="", owner=""):
        #Defered import 
        from ToolUser.models import ToolUser
        resultsDict = {}
        MainLst = []
        if name != "":
            for tool in Tool.objects.exclude(currOwner=0).filter(name__icontains=name):
                if tool.id in resultsDict.keys():
                    resultsDict[tool.id] += 1
                else:
                    resultsDict[tool.id] = 1                    
        if owner != "":
            for tool in Tool.objects.exclude(currOwner=0):
                for user in ToolUser.objects.filter(name__icontains=owner):
                    if tool.owner == user.id:
                        if tool in resultsDict.keys():
                            resultsDict[tool.id] += 1
                        else:
                            resultsDict[tool.id] = 1
        for item in resultsDict:
            MainLst.append([item, resultsDict[item]])
        MainLst.sort(key=lambda tool: tool[1])
        return MainLst
    

class Shed(models.Model):
    location = models.IntegerField(max_length=5)        #Zip Code
    coordinator = models.IntegerField(max_length=50)    #ID of coordinator
    title = models.CharField(max_length=50)             #title of shed
    
    def __str__(self):
        return self.id

    def changeCoordinator(self, newCoordinator):
        self.coordinator = newCoordinator
        self.save()
        
    def getTools(self):
        mainLst = []
        """for tool in self.tool_set.filter(isAvailable=1):
            tempLst = [tool.id, tool.name, tool.description, tool.currOwner]
            mainLst.append(tempLst)"""
        for tool in Tool.objects.filter(shed=self.id):
            mainLst.append([tool.id,tool.name,tool.description,tool.currOwner])
        return mainLst

    #Add a tool to the shed
    def addTool(self, toolID):
        theDict = ShareZone.allTools()
        for tool in theDict:
            if tool.getID() == toolID and tool.currOwner==0:
                tool.shed = self.id
                tool.save()