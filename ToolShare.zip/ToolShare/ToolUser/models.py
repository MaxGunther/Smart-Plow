from django.db import models
from django.contrib import auth
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from ToolContainers.models import ShareZone, Shed
from Tool.models import Tool

class ToolUser(Shed):
    name = models.CharField(max_length=50)  #Name of User
    pic = models.FileField(upload_to="PicStatic/Profile/",\
                 default="PicStatic/Profile/default.png") #Profile picture
    
    def __str__(self):
        return self.id
    
    def getID(self):
        return self.id
    
    def move(self, newLocation):
        self.location = newLocation
        self.save()
        
    def addPic(self):
        pass
        """with open('../Static/PicStatic/Profiles/'+self.name+'.png', 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)"""
    
    def changeNotification(self, request):
        operation = request.POST.get("operation","noop")
        if operation == "read":
            pass
        if operation == "approve":
            pass
        if operation == "deny":
            pass
        if operation == "delete":
            pass
    
    def submitTool(self, Nname, Ndescription):
        t = Tool(name=Nname, owner=self.id, shed=self.id, description=Ndescription, borrowOn=0, due=0, currOwner=0, location=self.location)
        t.save()
    
    def removeTool(self, toolID):
        t = Tool.objects.get(id=toolID)
        if t.currOwner == 0:
            t.delete()
        #Make an else with an error message that tool wasn't
        #Deleted because it's borrowed
    
    def getSheds(self):
        lst = []
        for shed in Shed.objects.filter(coordinator=self.id):
            lst.append([shed.id,shed.location,shed.title])
        return lst
    
    def querySet(self, toolSet, nameQuery="", descQuery="", ownerQuery="", availQuery=True):
        if nameQuery:
            toolSet = toolSet.filter(name__contains=nameQuery)
        if descQuery:
            toolSet = toolSet.filter(description__contains=descQuery)
        if availQuery:
            toolSet = toolSet.filter(currOwner=0)
        return toolSet
    
    def getOwnedTools(self, nameQuery="", descQuery="", ownerQuery="", availQuery=True):
        #Get all tools owned the user
        mainLst = []
        #toolSet = Tool.objects.all()
        toolSet = self.querySet(Tool.objects.filter(owner__exact=self.id),nameQuery,descQuery,ownerQuery,availQuery)
        for tool in toolSet:
            toolLst = [tool.id, tool.name, tool.description, tool.currOwner, tool.currOwner==0, tool.shed]
            mainLst.append(toolLst)
        mainLst.sort(key=lambda tool: -tool[0])
        return mainLst

    def getBorrowedTools(self):
        #Get all tools being borrowed by the user
        mainLst = []
        for tool in Tool.objects.filter(currOwner__exact=self.id):
            toolLst = [tool.id, tool.name, tool.description, tool.currOwner]
            mainLst.append(toolLst)
        mainLst.sort(key=lambda tool: -tool[0])
        return mainLst

    def getAvailableTools(self, nameQuery="", descQuery="", ownerQuery="", availQuery=True):
        #Get all tools user is allowed to borrow
        mainLst = []
        toolSet = Tool.objects.filter(location__exact=self.location).exclude(owner=self.id)
        toolSet = self.querySet(toolSet, nameQuery, descQuery, ownerQuery, availQuery)
        for tool in toolSet:
            toolLst = [tool.id, tool.name, tool.description, tool.currOwner]
            mainLst.append(toolLst)
        return mainLst
    
    def getNotifications(self):
        from Notification.models import Notification
        
        userID = self.id
        messages = [[],[],[],[]]
        notificationSet = Notification.objects.filter(user=userID).extra(order_by=['-borrowOn'])
        for msg in notificationSet:
            tool = Tool.objects.get(id=msg.tool)
            toolName = tool.name
            toolDesc = tool.description
            borrowerName = ToolUser.objects.get(id=msg.borrowerID).name
            msgList = [msg.id, msg.tool, toolName, toolDesc, borrowerName, msg.borrowOn, msg.due]
            if msg.isDenied==1:
                messages[2].append(msgList)
            elif msg.isDenied==2:
                messages[3].append(msgList)
            elif msg.isRead==0:
                messages[0].append(msgList)
            else:
                messages[1].append(msgList)
        #messages[1].append([0,0,"Tool name here","Tool desc here",1398790289875,1398790389875])
        return messages
    
    def deleteShed(self,shedID):
        shed = Shed.objects.get(id=shedID)
        tools = shed.getTools()
        for tool in tools:
            if tool[3] != 0:
                return False
        
        for tool in tools:
            self.removeTool(tool[0])
        shed.delete()
        
        return True
    
    def deleteTools(self):
        mainDict = self.getOwnedTools()
        canDelete = True
        
        for tool in mainDict:
            #If tool is being borrowed, set flag
            if tool[3] != 0:
                canDelete = False

        #If we can delete, do so
        if canDelete:
            for tool in mainDict:
                self.removeTool(tool[0])


        #return whether the tools were deleted or not
        return canDelete
    
    @staticmethod
    def loginMember(request):
        name = request.POST.get('name', '')
        password = request.POST.get('password', '')
        #Authenticate user and check if they're active
        userDjango = auth.authenticate(username=name, password=password)
        if (userDjango != None) and userDjango.is_active:
            #Log them in, set session data
            auth.login(request, userDjango)
            request.session["member"] = request.user.username
            # Redirect to userHome
            return HttpResponseRedirect("userHome")
        # Return to login, set fail flag
        request.session["loginFail"] = True
        return HttpResponseRedirect("login")
        
    @staticmethod
    def logoutMember(request):
        auth.logout(request)
        try:
            del request.session["member"]
        except KeyError:
            pass
    
    @staticmethod  
    def registerMember(request):
        #Gather info
        PostName = request.POST.get('name','')
        zipcode = request.POST.get('zipcode','')
        PostPassword = request.POST.get('password','')
        PostPasswordCheck = request.POST.get('password2','')
        #Check for incorrect feilds or missmatched password
        if PostName == '' or zipcode == '' or PostPassword == '' or PostPasswordCheck == ''\
                          or (PostPassword != PostPasswordCheck) or (not zipcode.isdigit()):
            if PostName == '':
                request.session["noName"] = True
            if zipcode == '':
                request.session["noZip"] = True
            if (not zipcode.isdigit()) or (len(zipcode) != 5):
                request.session["zipInvaild"] = True
            if PostPassword == '':
                request.session["noPass"] = True
            if PostPasswordCheck == '':
                request.session["noPassCheck"] = True
            if PostPassword != PostPasswordCheck:
                request.session["PassNoMatch"] = True
            return HttpResponseRedirect("register")
        #Check if 'person' in Database, sets flags
        if ToolUser.objects.filter(name=PostName).exists():
            request.session["nameTaken"] = True
            return HttpResponseRedirect("register")
        else:
            #Create and save tables if needed
            if ShareZone.objects.filter(location=zipcode).exists():
                pass
            else:
                shareZ = ShareZone(location=zipcode)
                shareZ.save()
            userDjango = User.objects.create_user(username=PostName, password=PostPassword)        
            Tooluser = ToolUser(name=PostName, location=zipcode, coordinator=-1)
            userDjango.save()
            Tooluser.save()
            #login user
            userAuth = auth.authenticate(username=PostName, password=PostPassword)
            if userAuth is not None and userAuth.is_active:
                #Clear old flags and set current data
                request.session.flush()
                auth.login(request, userAuth)
                request.session["member"] = PostName
                #Redirect to userhome
                return HttpResponseRedirect("userHome")
