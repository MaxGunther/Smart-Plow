from django.test import TestCase
from Tool.models import Tool
from ToolUser.models import ToolUser

class Max_test_case2(TestCase):
    def test(self):
    	user1 = ToolUser(name = "Alex", location = 11111, coordinator = -1)
    	user2 = ToolUser(name = "Charlie", location = 11111, coordinator = -1)
    	self.assertEqual(user1.location, user2.location)
    	self.assertEqual(user1.location, user2.location)
    	self.assertEqual(user1.name, "Alex")
    	self.assertEqual(user2.name, "Charlie")