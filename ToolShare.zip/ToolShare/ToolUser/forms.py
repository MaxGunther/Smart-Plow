from django import forms

class PictureUpload(forms.Form):
    docfile = forms.FileField(
        label='Profile pic'
    )