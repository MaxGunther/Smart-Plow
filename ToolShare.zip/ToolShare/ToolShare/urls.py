from django.conf.urls import patterns, url
from django.conf import settings
from django.conf.urls.static import static

from django.contrib import admin
admin.autodiscover()

from ToolShare.views import home, login, logout, userHome, regUser, \
                        account, tools, importTools, notifications, \
                        sheds, importSheds, postOp, search, importSearch

urlpatterns = patterns('',
    url(r'^$', home),
    url(r'^home', home),
    url(r'^login', login),
    url(r'^logOut', logout),
    url(r'^userHome', userHome),
    url(r'^register', regUser),
    url(r'^sheds', sheds),
    url(r'^myAccount', account),
	url(r'^tools', tools),
	url(r'^importTools', importTools),
    url(r'^notifications', notifications),
    url(r'^postOp', postOp),
    url(r'^importSheds', importSheds),
    url(r'^search', search),
    url(r'^importSearch', importSearch),
) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

"""
urlpatterns = patterns('',
    url(r'^$', home),
    url(r'^home', home),
    url(r'^login', login),
    url(r'^logOut', logout),
    url(r'^userHome', userHome),
    url(r'^register', regUser),
    url(r'^sheds', sheds),
    url(r'^myAccount', account),
	url(r'^tools', tools),
	url(r'^importTools', importTools),
    url(r'^notifications', notifications),
    url(r'^postOp', postOp),
    url(r'^importSheds', importSheds),
) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
"""