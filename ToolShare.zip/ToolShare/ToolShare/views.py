from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required

from Tool.models import Tool
from ToolUser.models import ToolUser
from ToolUser.forms import PictureUpload
from ToolContainers.models import Shed, ShareZone

def home(request):
    #Load Hompage
    temp = get_template('start.html')
    user = request.user
    auth = user.is_authenticated()
    username = request.session.get("member","Guest")
    context = Context({"user":username,"authorized":auth})
    return HttpResponse(temp.render(context))

def login(request):
    #If requesting to log in
    if request.method == 'POST':
        if "zipcode" in request.session:
            zipcode = request.session["zipcode"]
            request.session.flush()
            request.session["zipcode"] = zipcode
        else:
            request.session.flush()
        response = ToolUser.loginMember(request)
        return response
    #Normal render
    else:
        temp = get_template('login.html')
        user = request.user
        context = Context({"user":"Guest","authorized":user.is_authenticated()})
        if "loginFail" in request.session:
            context["loginFail"] = request.session["loginFail"]
        else:
            context["loginFail"] = False
        html = temp.render(context)
        return HttpResponse(html)

def logout(request):
    ToolUser.logoutMember(request)
    return HttpResponseRedirect("home")

def regUser(request):
    #If registering
    if request.method == 'POST':
        #Flush session and register
        if "zipcode" in request.session:
            zipcode = int(request.session["zipcode"])
            request.session.flush()
            request.session["zipcode"] = zipcode
        else:
            request.session.flush()
        response = ToolUser.registerMember(request)
        return response
    #Normal render
    else:
        temp = get_template('userReg.html')
        #Build context
        context = Context()
        if "nameTaken" in request.session:
            context["nameTaken"] = request.session["nameTaken"]
        else:
            context["nameTaken"] = False
        if "noName" in request.session:
            context["noName"] = request.session["noName"]
        else:
            context["noName"] = False
        if "noZip" in request.session:
            context["noZip"] = request.session["noZip"]
        else:
            context["noZip"] = False
        if "zipInvaild" in request.session:
            context["zipInvaild"] = request.session["zipInvaild"]
        else:
            context["zipInvaild"] = False
        if "noPass" in request.session:
            context["noPass"] = request.session["noPass"]
        else:
            context["noPass"] = False
        if "noPassCheck" in request.session:
            context["noPassCheck"] = request.session["noPassCheck"]
        else:
            context["noPass"] = False
        #Clear old flags and render
        if "zipcode" in request.session:
            zipcode = request.session["zipcode"]
            request.session.flush()
            request.session["zipcode"] = zipcode
        else:
            request.session.flush()
        html = temp.render(context)
        return HttpResponse(html)

def userHome(request):
    temp = get_template('userHome.html')
    #Build context
    auth = request.user
    is_auth = auth.is_authenticated()
    username = request.session.get("member","Guest")
    borrowed = 0
    lent = 0
    """if not is_auth:
        return HttpResponseRedirect("home")"""
    if is_auth:
        userObj = ToolUser.objects.get(name=username)
        borrowed = userObj.getBorrowedTools().__len__()
        lent = Tool.objects.filter(owner=userObj.id).exclude(currOwner=0).__len__()
    
    context = Context({
        "user":username,
        "borrowed":borrowed,
        "lent":lent,
        "authorized":is_auth})
    
    html = temp.render(context)
    return HttpResponse(html)

@login_required(login_url=login)
def account(request):
    username = request.session.get("member","Guest")
    if request.method == 'POST':
        #Unregister
        member = ToolUser.objects.get(name=username)
        #Check if tools can be deleted
        if member.deleteTools():
            member.delete()
            user =  request.user
            user.delete()
            request.session.flush()
            return HttpResponseRedirect('home')
        #Otherwise, redirect back to Unregister and say why
        else:
            #Error message here, either popup or in-page that a tool is being borrowed
            return HttpResponseRedirect('myAccount')
    else:
        #Normal render
        temp = get_template('myAccount.html')
        Djangouser = request.user
        member = ToolUser.objects.get(name=username)
        form = PictureUpload()
        picture = "PicStatic/Profiles/"+username+".png"
        html = temp.render(Context({"user":username,"authorized":Djangouser.is_authenticated(), \
                                    "picture" : picture, "form" : form}))
        return HttpResponse(html)

def tools(request):
    #If Tool operation
    if not request.method == 'POST':
        #Normal render
        temp = get_template('tools.html')
        username = request.session.get("member","Guest")
        user = request.user
        auth = user.is_authenticated()
        mySheds = []
        if auth:
            userObj = ToolUser.objects.get(name=username)
            mySheds = userObj.getSheds()
            zipcode = userObj.location
        else:
            zipcode = int(request.session.get("zipcode","14623"))
            sheds = Shed.objects.filter(location=zipcode)
            for shed in sheds:
                mySheds.append([shed.id,shed.location,shed.title])
        
        html = temp.render(Context({"user":username,"MySheds":mySheds,"authorized":auth}))
        return HttpResponse(html)

def importTools(request):
    mySheds = []
    myTools = []
    borrowedTools = []
    otherTools = []
    userDjango = request.user
    
    nameFilter=request.POST.get("searchName","")
    descFilter=request.POST.get("searchDesc","")
    userFilter=request.POST.get("searchUser","")
    availFilter=request.POST.get("searchAvail",False)
    
    if userDjango.is_authenticated():
        username = request.session["member"]
        user = ToolUser.objects.get(name=username)
        mySheds = user.getSheds()
        myTools = user.getOwnedTools()
        borrowedTools = user.getBorrowedTools()
        otherTools = user.getAvailableTools(nameFilter,descFilter,userFilter,availFilter)
    else:
        otherTools = []
        toolsAll = []
        """if "zipcode" in request.session:
            zipcode = request.session["zipcode"]
            toolsAll = Tool.objects.filter(location=zipcode)
        else:
            toolsAll = Tool.objects.all()
        if nameFilter:
            toolsAll = toolsAll.filter(name__contains=nameFilter)
            if descFilter:
                toolsAll = toolsAll.filter(description__contains=descFilter)
            if userFilter:
                pass
            if availFilter:
                toolsAll = toolsAll.filter(currOwner=0)"""
        toolsAll = Tool.objects.all()
        for tool in toolsAll:
            shed = Shed.objects.get(id=tool.shed)
            toolLst = [tool.id, tool.name, tool.description, tool.currOwner, tool.currOwner==0, shed.title]
            otherTools.append(toolLst)
        
    context = Context({'MyTools':myTools, 'BorrowedTools':borrowedTools, 'OtherTools':otherTools, "MySheds":mySheds, 'success':True, "authorized":userDjango.is_authenticated()})
    temp = get_template('tools.xml')
    html = temp.render(context)
    return HttpResponse(html)

def sheds(request):
    mySheds = []
    userDjango = request.user
    auth = userDjango.is_authenticated()
    username = request.session.get("member","Guest")
    # Replace hard-coded zipcode or guarantee zipcode exists
    zipcode = request.session.get("zipcode",14623)
    if auth:
        user = ToolUser.objects.get(name=username)
        zipcode = user.location
        mySheds = user.getSheds()
    neighbors = ToolUser.objects.filter(location=zipcode)
    coordinators = []
    for neighbor in neighbors:
        coordinators.append([neighbor.id,neighbor.name])
    numSheds=mySheds.__len__()
    plural = "s"
    if numSheds==1:
        plural = ""
    context = Context({"sheds":mySheds,"numSheds":numSheds,"numShedsPlural":plural,\
        "coordinators":coordinators,"user":username,"authorized":auth})
    temp = get_template('sheds.html')
    return HttpResponse(temp.render(context))

def importSheds(request):
    mySheds = []
    userDjango = request.user
    auth = userDjango.is_authenticated()
    username = request.session.get("member","Guest")
    # Replace hard-coded zipcode or guarantee zipcode exists
    zipcode = request.session.get("zipcode",14623)
    if auth:
        user = ToolUser.objects.get(name=username)
        zipcode = user.location
        mySheds = user.getSheds()
    neighbors = ToolUser.objects.filter(location=zipcode)
    coordinators = []
    for neighbor in neighbors:
        coordinators.append([neighbor.id,neighbor.name])
    numSheds=mySheds.__len__()
    plural = "s"
    if numSheds==1:
        plural = ""
    context = Context({"sheds":mySheds,"numSheds":numSheds,"numShedsPlural":plural,\
        "coordinators":coordinators,"user":username,"authorized":auth})
    temp = get_template('sheds.xml')
    return HttpResponse(temp.render(context))

def postOp(request):
    if request.method == 'POST':
        origin = request.POST.get("origin","http://127.0.0.1:8000")
        operation = request.POST.get("operation","noop")
        zipcode = request.session.get("zipcode","14623")
        
        #Registered user operations
        if request.user.is_authenticated():
            username = request.session.get("member","Guest")
            user = ToolUser.objects.get(name=username)
            zipcode = user.location
            
            #Upload Picture
            if operation == "uploadPic":
                picForm = PictureUpload(request.POST, request.FILES)
                if picForm.is_valid():
                    newPic = PictureUpload(docfile = request.FILES['PicStatic/Profile/'])
                    newPic.save()
            #Delete
            if operation == "deleteTool":
                user.removeTool(request.POST.get('toolID',''))
            #AddTool
            if operation == "addTool":
                toolName = request.POST.get("toolName","")
                toolDesc = request.POST.get("toolDesc","")
                origin = request.POST.get("origin", "http://127.0.0.1:8000/tools")
                user.submitTool(toolName, toolDesc)
                con = Context({"user":username,"zipcode":zipcode})
                return HttpResponse(get_template("tools.html").render(con))
            #Borrowing
            elif operation == "borrowTool":
                tool = Tool.objects.get(id=request.POST.get('toolID',''))
                tool.checkOut(user.id)
            #Request Tool
            elif operation == "requestTool":
                tool = Tool.objects.get(id=request.POST.get('toolID',''))
                #borrowTime = request.POST.get("startTime", 0)
                #due = request.POST.get("endTime", 0)
                #tool.request(user.id, borrowTime, due)
                tool.checkIn(user.id)
            #Returning tools
            elif operation == "returnTool":
                tool = Tool.objects.get(id=request.POST.get('toolID',''))
                tool.checkIn()
            #AddShed
            elif operation == "addShed":
                shedName = request.POST.get("shedName","Untitled")
                coordinator = request.POST.get("coordinator","Guest")
                coordinatorObj = ToolUser.objects.get(name=coordinator)
                coordID = coordinatorObj.id
                ShareZone.objects.get(location=zipcode).createShed(coordID, shedName)
            #Delete Shed
            if operation == "deleteShed":
                user.deleteShed(request.POST.get("shedID","-1"))
            #Notifications
            if operation == "changeNotification":
                user.changeNotification(request)
            #Change cordnator
            if operation == "giveShed":
                shed = int(request.POST.get("shedID","Guest"))
                NewCordName = request.POST.get("userName","Guest")
                coordinator = ToolUser.objects.get(name = NewCordName)
                shedObject = Shed.objects.get(id = shed)
                shedObject.changeCoordinator(coordinator.id)
            if origin == "":
                origin = "http://127.0.0.1:8000"
            return HttpResponseRedirect(origin)
        #Guest operations
        else:
            # Replace hard-coded zipcode or guarantee zipcode exists
            zipSession = int(request.session.get("zipcode","14623"))
            zipPost = int(request.POST.get("zipcode","14623"))
            if origin == "tools":
                #Adding Tool as guest
                toolname = request.POST.get('toolName','')
                desc = request.POST.get('toolDesc','')
                tool = Tool(name=toolname, owner=-1, shed=-1, description=desc, currOwner=0, location=zipSession)
            elif origin == "sheds":
                #Adding Shed as guest
                shedName = request.POST.get("shedName","Untitled")
                coord = request.POST.get("coordinator","Guest")
                shed = Shed(shedName,coord)
                shed.save()
            elif origin == "changeZip":
                #Change session zipcode of guest
                request.session['zipcode'] = zipPost
            return HttpResponseRedirect(origin)
    else:
        return HttpResponseRedirect("tools.html")

def notifications(request):
    username = request.session.get("member","Guest")
    userDjango = request.user
    auth = userDjango.is_authenticated()
    messages = [[],[],[],[]]
    zipcode = request.session.get("zipcode","14623")
    someUnread = False
    if auth:
        userObj = ToolUser.objects.get(name=username)
        messages = userObj.getNotifications()
        if messages[0]:
            someUnread = True
    context = Context({"user":username,"notifications":messages,"unread":someUnread,\
        "authorized":auth,"currentZip":zipcode})
    html = get_template('notifications.xml').render(context)
    return HttpResponse(html)

def importSearch(request):
    username = request.session.get("member","Guest")
    userDjango = request.user
    auth = userDjango.is_authenticated()
    zipcode = request.session.get("zipcode","14623")
    
    query = request.POST.get("query","")
    includeTools = request.POST.get("includeTools","True")=="True"
    includeSheds = request.POST.get("includeSheds","True")=="True"
    #includeUsers = request.POST.get("includeUsers","True")=="True"
    #print(query,includeTools,includeSheds,includeUsers)
    toolMatches = []
    if includeTools:
        tools = Tool.objects.filter(name__contains=query)
        for tool in tools:
            toolMatches.append([tool.id, tool.name, tool.description, tool.borrowOn, tool.due, tool.location, tool.currOwner, tool.shed])
    
    shedMatches = []
    if includeSheds:
        sheds = Shed.objects.filter(title__contains=query)
        for shed in sheds:
            shedMatches.append([shed.id, shed.title, shed.location, shed.coordinator])
    
    """userMatches = []
    if includeUsers:
        users = ToolUser.objects.filter(name__contains=query)
        for user in users:
            userMatches.append([user.id, user.name])"""
    con = Context({"user":username,"authorized":auth,"zipcode":zipcode, "toolMatches":toolMatches, "shedMatches":shedMatches})
    
    
    return HttpResponse(get_template('search.xml').render(con))

def search(request):
    username = request.session.get("member","Guest")
    userDjango = request.user
    auth = userDjango.is_authenticated()
    zipcode = request.POST.get("zipcode",request.session.get("zipcode","14623"))
    con = Context({"user":username,"zipcode":zipcode,"authorized":auth})
    return HttpResponse(get_template('search.html').render(con))